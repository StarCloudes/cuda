import pandas as pd
import matplotlib.pyplot as plt

# Load Task 3 (single precision) results from a TXT file.
df_single = pd.read_csv("task03_results.txt", delimiter=",")
# Load Task 4 (double precision) results from a TXT file.
df_double = pd.read_csv("task04_results.txt", delimiter=",")

# Merge the two DataFrames on common columns: Matrix_n, Matrix_m, and ThreadsPerBlock.
df_merged = pd.merge(df_single, df_double, on=["Matrix_n", "Matrix_m", "ThreadsPerBlock"],
                     suffixes=('_single', '_double'))

# Choose the optimal ThreadsPerBlock (e.g., 256)
optimal_threads = 256
df_opt = df_merged[df_merged["ThreadsPerBlock"] == optimal_threads]

# Assume Matrix_n equals Matrix_m and sort by matrix size.
df_opt = df_opt.sort_values("Matrix_n")

# --------------------------
# Figure 1: Speedup Comparison
# --------------------------
plt.figure(figsize=(8, 6))

# Plot row sum calculation speedup.
plt.plot(df_opt["Matrix_n"], df_opt["RowSumCalcSpeedup_single"],
         marker='^', linestyle="--", label="Row Sum (single)")
plt.plot(df_opt["Matrix_n"], df_opt["RowSumCalcSpeedup_double"],
         marker='o', linestyle="-", label="Row Sum (double)")

# Plot column sum calculation speedup.
plt.plot(df_opt["Matrix_n"], df_opt["ColSumCalcSpeedup_single"],
         marker='^', linestyle="--", label="Col Sum (single)")
plt.plot(df_opt["Matrix_n"], df_opt["ColSumCalcSpeedup_double"],
         marker='o', linestyle="-", label="Col Sum (double)")

plt.title(f"Speedup Comparison at ThreadsPerBlock = {optimal_threads}")
plt.xlabel("Matrix Size (n = m)")
plt.ylabel("Speedup (x)")
plt.grid(True)
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig("task04_speedup_plot.png", dpi=300)
plt.show()

# --------------------------
# Figure 2: Error Comparison
# --------------------------
plt.figure(figsize=(8, 6))

# Plot row relative error.
plt.plot(df_opt["Matrix_n"], df_opt["RowRelError_single"],
         marker='^', linestyle="--", label="Row Error (single)")
plt.plot(df_opt["Matrix_n"], df_opt["RowRelError_double"],
         marker='o', linestyle="-", label="Row Error (double)")

# Plot column relative error.
plt.plot(df_opt["Matrix_n"], df_opt["ColumnRelError_single"],
         marker='^', linestyle="--", label="Col Error (single)")
plt.plot(df_opt["Matrix_n"], df_opt["ColumnRelError_double"],
         marker='o', linestyle="-", label="Col Error (double)")

plt.title(f"Error Comparison at ThreadsPerBlock = {optimal_threads}")
plt.xlabel("Matrix Size (n = m)")
plt.ylabel("Relative Error")
plt.grid(True)
plt.legend(fontsize=8)
plt.tight_layout()
plt.savefig("task04_error_plot.png", dpi=300)
plt.show()