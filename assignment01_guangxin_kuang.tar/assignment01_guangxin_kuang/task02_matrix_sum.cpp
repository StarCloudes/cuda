#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <getopt.h>
#include <cuda_runtime.h>

// Function prototypes for CPU implementation
void sumAbsRows(float *matrix, float *rowSums, int n, int m);
void sumAbsCols(float *matrix, float *colSums, int n, int m);
float reduceVector(float *vector, int size);
float printTiming(const char *operation, double cpuTimeMs, double gpuTimeMs);
float compareResults(float cpuResult, float gpuResult, const char *operation);
void appendResultsToCSV(const char *filename, 
    int n, int m, int threadsPerBlock,
    float cpuRowTotal, float gpuRowTotal,
    float cpuColTotal, float gpuColTotal,
    float rowRelativeError, float columnRelativeError,
    float rowSumCalcSpeedup, float colSumCalcSpeedup,
    float rowReductionSpeedup, float colReductionSpeedup);


// Function prototypes for CUDA implementation (defined in cuda_kernels.cu)
extern "C" {
    void cudaSumAbsRows(float *h_matrix, float *h_rowSums, int n, int m, float *d_matrix, float *d_rowSums, 
                        int threadsPerBlock, double *timeMs);
    void cudaSumAbsCols(float *h_matrix, float *h_colSums, int n, int m, float *d_matrix, float *d_colSums, 
                        int threadsPerBlock, double *timeMs);
    float cudaReduceVector(float *h_vector, int size, float *d_vector, float *d_tempResults, 
                           int threadsPerBlock, double *timeMs);
}

int main(int argc, char **argv) {
    // Default values
    int n = 10;
    int m = 10;
    int randomSeed = 0;
    int showTiming = 0;
    int threadsPerBlock = 256;
    
    // Parse command line arguments
    int opt;
    while ((opt = getopt(argc, argv, "n:m:rtb:")) != -1) {
        switch (opt) {
            case 'n':
                n = atoi(optarg);
                break;
            case 'm':
                m = atoi(optarg);
                break;
            case 'r':
                randomSeed = 1;
                break;
            case 't':
                showTiming = 1;
                break;
            case 'b':
                threadsPerBlock = atoi(optarg);
                break;
            default:
                fprintf(stderr, "Usage: %s [-n rows] [-m cols] [-r] [-t] [-b threadsPerBlock]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }
    
    // Seed random number generator
    if (randomSeed) {
        struct timeval myRandom;
        gettimeofday(&myRandom, NULL);
        srand48((int)(myRandom.tv_usec));
    } else {
        srand48(1234567);
    }
    
    // Allocate memory for matrix
    float *matrix = (float *)malloc(n * m * sizeof(float));
    if (!matrix) {
        fprintf(stderr, "Memory allocation failed for matrix\n");
        exit(EXIT_FAILURE);
    }
    
    // Initialize matrix with random values between -20 and 20
    for (int i = 0; i < n * m; i++) {
        matrix[i] = ((float)(drand48()) * 40.0f) - 20.0f;
    }
    
    // Allocate memory for CPU row and column sums
    float *cpuRowSums = (float *)malloc(n * sizeof(float));
    float *cpuColSums = (float *)malloc(m * sizeof(float));
    if (!cpuRowSums || !cpuColSums) {
        fprintf(stderr, "Memory allocation failed for CPU sums\n");
        free(matrix);
        exit(EXIT_FAILURE);
    }
    
    // Allocate memory for GPU row and column sums
    float *gpuRowSums = (float *)malloc(n * sizeof(float));
    float *gpuColSums = (float *)malloc(m * sizeof(float));
    if (!gpuRowSums || !gpuColSums) {
        fprintf(stderr, "Memory allocation failed for GPU sums\n");
        free(matrix);
        free(cpuRowSums);
        free(cpuColSums);
        exit(EXIT_FAILURE);
    }
    
    // CPU Timing variables
    struct timeval start, end;
    double cpuRowSumTime, cpuColSumTime, cpuRowReduceTime, cpuColReduceTime;
    
    // GPU Timing variables
    double gpuRowSumTime, gpuColSumTime, gpuRowReduceTime, gpuColReduceTime;
    
    // CPU Calculation
    printf("Performing CPU calculations...\n");
    
    // Calculate row sums on CPU
    gettimeofday(&start, NULL);
    sumAbsRows(matrix, cpuRowSums, n, m);
    gettimeofday(&end, NULL);
    cpuRowSumTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Calculate column sums on CPU
    gettimeofday(&start, NULL);
    sumAbsCols(matrix, cpuColSums, n, m);
    gettimeofday(&end, NULL);
    cpuColSumTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Reduce row sums on CPU
    gettimeofday(&start, NULL);
    float cpuRowTotal = reduceVector(cpuRowSums, n);
    gettimeofday(&end, NULL);
    cpuRowReduceTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Reduce column sums on CPU
    gettimeofday(&start, NULL);
    float cpuColTotal = reduceVector(cpuColSums, m);
    gettimeofday(&end, NULL);
    cpuColReduceTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // GPU Calculation
    printf("Performing GPU calculations...\n");
    
    // Allocate device memory
    float *d_matrix, *d_rowSums, *d_colSums, *d_tempResults;
    cudaMalloc((void **)&d_matrix, n * m * sizeof(float));
    cudaMalloc((void **)&d_rowSums, n * sizeof(float));
    cudaMalloc((void **)&d_colSums, m * sizeof(float));
    
    // Allocate temp results for reduction (we'll use the max of n and m)
    int maxBlocks = (n > m) ? (n + threadsPerBlock - 1) / threadsPerBlock : (m + threadsPerBlock - 1) / threadsPerBlock;
    cudaMalloc((void **)&d_tempResults, maxBlocks * sizeof(float));
    
    // Calculate row sums on GPU
    cudaSumAbsRows(matrix, gpuRowSums, n, m, d_matrix, d_rowSums, threadsPerBlock, &gpuRowSumTime);
    
    // Calculate column sums on GPU
    cudaSumAbsCols(matrix, gpuColSums, n, m, d_matrix, d_colSums, threadsPerBlock, &gpuColSumTime);
    
    // Reduce row sums on GPU
    float gpuRowTotal = cudaReduceVector(gpuRowSums, n, d_rowSums, d_tempResults, threadsPerBlock, &gpuRowReduceTime);
    
    // Reduce column sums on GPU
    float gpuColTotal = cudaReduceVector(gpuColSums, m, d_colSums, d_tempResults, threadsPerBlock, &gpuColReduceTime);

    // Print results
    printf("\nMatrix size: %d x %d\n", n, m);
    printf("Threads per block: %d\n\n", threadsPerBlock);
    
    printf("CPU Row sum reduction: %f\n", cpuRowTotal);
    printf("GPU Row sum reduction: %f\n", gpuRowTotal);
    float rowRelativeError = compareResults(cpuRowTotal, gpuRowTotal, "Row sum reduction");
    
    printf("\nCPU Column sum reduction: %f\n", cpuColTotal);
    printf("GPU Column sum reduction: %f\n", gpuColTotal);
    float columnRelativeError = compareResults(cpuColTotal, gpuColTotal, "Column sum reduction");
    
    // Print timing information if requested
    if (showTiming) {
        printf("\nTiming Information:\n");
        float rowSumCalcSpeedup = printTiming("Row sum calculation", cpuRowSumTime, gpuRowSumTime);
        float colSumCalcSpeedup = printTiming("Column sum calculation", cpuColSumTime, gpuColSumTime);
        float rowReductionSpeedup = printTiming("Row sum reduction", cpuRowReduceTime, gpuRowReduceTime);
        float colReductionSpeedup = printTiming("Column sum reduction", cpuColReduceTime, gpuColReduceTime);

        // Write to the files
        appendResultsToCSV("results.txt", n, m, threadsPerBlock,
            cpuRowTotal, gpuRowTotal,
            cpuColTotal, gpuColTotal,
            rowRelativeError, columnRelativeError,
            rowSumCalcSpeedup, colSumCalcSpeedup,
            rowReductionSpeedup, colReductionSpeedup);
    }
    
    // Free device memory
    cudaFree(d_matrix);
    cudaFree(d_rowSums);
    cudaFree(d_colSums);
    cudaFree(d_tempResults);
    
    // Free host memory
    free(matrix);
    free(cpuRowSums);
    free(cpuColSums);
    free(gpuRowSums);
    free(gpuColSums);
    
    return 0;
}

// Calculate absolute sum of each row
void sumAbsRows(float *matrix, float *rowSums, int n, int m) {
    for (int i = 0; i < n; i++) {
        rowSums[i] = 0.0f;
        for (int j = 0; j < m; j++) {
            rowSums[i] += fabsf(matrix[i * m + j]);
        }
    }
}

// Calculate absolute sum of each column
void sumAbsCols(float *matrix, float *colSums, int n, int m) {
    for (int j = 0; j < m; j++) {
        colSums[j] = 0.0f;
        for (int i = 0; i < n; i++) {
            colSums[j] += fabsf(matrix[i * m + j]);
        }
    }
}

// Reduce vector by summing all elements
float reduceVector(float *vector, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += vector[i];
    }
    return sum;
}

// Print timing information
float printTiming(const char *operation, double cpuTimeMs, double gpuTimeMs) {
    float speedup = cpuTimeMs / gpuTimeMs;
    printf("%s time - CPU: %.3f ms, GPU: %.3f ms, Speedup: %.2fx\n", 
           operation, cpuTimeMs, gpuTimeMs, cpuTimeMs / gpuTimeMs);
    return speedup;
}

// Compare CPU and GPU results
float compareResults(float cpuResult, float gpuResult, const char *operation) {
    float relError = fabs(cpuResult - gpuResult) / fabs(cpuResult);
    printf("Relative error for %s: %.9f (%.9f%%)\n", operation, relError, relError * 100.0);
    return relError;
}

// Write results
void appendResultsToCSV(const char *filename, 
    int n, int m, int threadsPerBlock,
    float cpuRowTotal, float gpuRowTotal,
    float cpuColTotal, float gpuColTotal,
    float rowRelativeError, float columnRelativeError,
    float rowSumCalcSpeedup, float colSumCalcSpeedup,
    float rowReductionSpeedup, float colReductionSpeedup) {
    
    // Open the file in append mode
    FILE *fp = fopen(filename, "a");
    if (!fp) {
        printf("Error: Cannot open file %s for writing.\n", filename);
        return;
    }
    
    // Check if the file is empty, and if so, write the CSV header line
    fseek(fp, 0, SEEK_END);
    if (ftell(fp) == 0) {
        fprintf(fp, "Matrix_n,Matrix_m,ThreadsPerBlock,CPU_Row_Sum,GPU_Row_Sum,CPU_Col_Sum,GPU_Col_Sum,RowRelError,ColumnRelError,RowSumCalcSpeedup,ColSumCalcSpeedup,RowReductionSpeedup,ColReductionSpeedup\n");
    }
    
    // Write the data as a single CSV row with comma-separated values
    fprintf(fp, "%d,%d,%d,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n",
            n, m, threadsPerBlock, 
            cpuRowTotal, gpuRowTotal, 
            cpuColTotal, gpuColTotal,
            rowRelativeError, columnRelativeError, 
            rowSumCalcSpeedup, colSumCalcSpeedup,
            rowReductionSpeedup, colReductionSpeedup);
    
    // Close the file after writing
    fclose(fp);
    printf("Results written successfully to '%s'\n", filename);
}