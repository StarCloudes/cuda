#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
#include <string.h>
#include <getopt.h>

// Function prototypes
void sumAbsRows(float *matrix, float *rowSums, int n, int m);
void sumAbsCols(float *matrix, float *colSums, int n, int m);
float reduceVector(float *vector, int size);
void printTiming(const char *operation, double timeMs);

int main(int argc, char **argv) {
    // Default values
    int n = 10;
    int m = 10;
    int randomSeed = 0;
    int showTiming = 0;
    
    // Parse command line arguments
    int opt;
    while ((opt = getopt(argc, argv, "n:m:rt")) != -1) {
        switch (opt) {
            case 'n':
                n = atoi(optarg);
                break;
            case 'm':
                m = atoi(optarg);
                break;
            case 'r':
                randomSeed = 1;
                break;
            case 't':
                showTiming = 1;
                break;
            default:
                fprintf(stderr, "Usage: %s [-n rows] [-m cols] [-r] [-t]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }
    
    // Seed random number generator
    if (randomSeed) {
        struct timeval myRandom;
        gettimeofday(&myRandom, NULL);
        srand48((int)(myRandom.tv_usec));
    } else {
        srand48(1234567);
    }
    
    // Allocate memory for matrix
    float *matrix = (float *)malloc(n * m * sizeof(float));
    if (!matrix) {
        fprintf(stderr, "Memory allocation failed for matrix\n");
        exit(EXIT_FAILURE);
    }
    
    // Initialize matrix with random values between -20 and 20
    for (int i = 0; i < n * m; i++) {
        matrix[i] = ((float)(drand48()) * 40.0f) - 20.0f;
    }
    
    // Allocate memory for row and column sums
    float *rowSums = (float *)malloc(n * sizeof(float));
    float *colSums = (float *)malloc(m * sizeof(float));
    if (!rowSums || !colSums) {
        fprintf(stderr, "Memory allocation failed for sums\n");
        free(matrix);
        exit(EXIT_FAILURE);
    }
    
    // Timing variables
    struct timeval start, end;
    double rowSumTime, colSumTime, rowReduceTime, colReduceTime;
    
    // Calculate row sums
    gettimeofday(&start, NULL);
    sumAbsRows(matrix, rowSums, n, m);
    gettimeofday(&end, NULL);
    rowSumTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Calculate column sums
    gettimeofday(&start, NULL);
    sumAbsCols(matrix, colSums, n, m);
    gettimeofday(&end, NULL);
    colSumTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Reduce row sums
    gettimeofday(&start, NULL);
    float rowTotal = reduceVector(rowSums, n);
    gettimeofday(&end, NULL);
    rowReduceTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Reduce column sums
    gettimeofday(&start, NULL);
    float colTotal = reduceVector(colSums, m);
    gettimeofday(&end, NULL);
    colReduceTime = (end.tv_sec - start.tv_sec) * 1000.0 + (end.tv_usec - start.tv_usec) / 1000.0;
    
    // Print results
    printf("Matrix size: %d x %d\n", n, m);
    printf("Row sum reduction: %f\n", rowTotal);
    printf("Column sum reduction: %f\n", colTotal);
    
    // Print timing information if requested
    if (showTiming) {
        printTiming("\nRow sum calculation", rowSumTime);
        printTiming("Column sum calculation", colSumTime);
        printTiming("Row sum reduction", rowReduceTime);
        printTiming("Column sum reduction", colReduceTime);
    }
    
    // Cleanup
    free(matrix);
    free(rowSums);
    free(colSums);
    
    return 0;
}

// Calculate absolute sum of each row
void sumAbsRows(float *matrix, float *rowSums, int n, int m) {
    for (int i = 0; i < n; i++) {
        rowSums[i] = 0.0f;
        for (int j = 0; j < m; j++) {
            rowSums[i] += fabsf(matrix[i * m + j]);
        }
    }
}

// Calculate absolute sum of each column
void sumAbsCols(float *matrix, float *colSums, int n, int m) {
    for (int j = 0; j < m; j++) {
        colSums[j] = 0.0f;
        for (int i = 0; i < n; i++) {
            colSums[j] += fabsf(matrix[i * m + j]);
        }
    }
}

// Reduce vector by summing all elements
float reduceVector(float *vector, int size) {
    float sum = 0.0f;
    for (int i = 0; i < size; i++) {
        sum += vector[i];
    }
    return sum;
}

// Print timing information
void printTiming(const char *operation, double timeMs) {
    printf("%s time: %.3f ms\n", operation, timeMs);
}