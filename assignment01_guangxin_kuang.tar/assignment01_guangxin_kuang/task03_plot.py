import pandas as pd
import matplotlib.pyplot as plt

# Read the TXT file
df = pd.read_csv("task03_results.txt")

# Define the matrix sizes to include (assuming Matrix_n equals Matrix_m)
sizes = [1000, 5000, 10000, 25000]

# Create a figure with 2 rows and 2 columns of subplots
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()  # Flatten the 2D array for easier iteration

# Iterate over each specified matrix size and its corresponding subplot
for i, size in enumerate(sizes):
    # Filter data for the current matrix size (both Matrix_n and Matrix_m equal to 'size')
    df_size = df[(df["Matrix_n"] == size) & (df["Matrix_m"] == size)]
    
    # Sort data by ThreadsPerBlock for proper x-axis ordering
    df_size = df_size.sort_values("ThreadsPerBlock")
    
    # Get the current subplot axis
    ax = axes[i]
    
    # Plot row speedup metrics with triangle markers
    ax.plot(df_size["ThreadsPerBlock"], df_size["RowSumCalcSpeedup"], marker='^', label="Row Sum Calculation")
    ax.plot(df_size["ThreadsPerBlock"], df_size["RowReductionSpeedup"], marker='^', label="Row Reduction")
    
    # Plot column speedup metrics with circle markers
    ax.plot(df_size["ThreadsPerBlock"], df_size["ColSumCalcSpeedup"], marker='o', label="Column Sum Calculation")
    ax.plot(df_size["ThreadsPerBlock"], df_size["ColReductionSpeedup"], marker='o', label="Column Reduction")
    
    # Set subplot title and axis labels
    ax.set_title(f"Matrix Size: {size} x {size}")
    ax.set_xlabel("Threads Per Block")
    ax.set_ylabel("Speedup (x)")
    ax.grid(True)
    ax.legend()

# Set a main title for the entire figure
fig.suptitle("CUDA Speedup Analysis for Various Matrix Sizes", fontsize=16)

# Adjust layout to prevent overlapping of subplots and the main title
plt.tight_layout(rect=[0, 0, 1, 0.95])

# Save the combined figure as a PNG file
plt.savefig("task03_speedup_plots.png", dpi=300)

# Display the figure
plt.show()